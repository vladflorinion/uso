#include "ops.h"

int opss = 6;

void set_no_ops(int ops)
{
    no_ops = ops;
}

int main(void)
{
    return 0;
}
