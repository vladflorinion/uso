#ifndef __OPS_H__
#define __OPS_H__

static int no_ops;
static short ops = 0;

static int get_no_ops()
{
    return no_ops;
}

#endif
