#include <stdio.h>

extern void a();
extern void b();
extern char **p;

int def_count(char **p)
{
    /**
     * TODO b: Dereference p until it contains the `STOP`
     * string
     * Return the number of dereferences
     */
}

int main(void)
{
    a();
    b();
    return 0;
}
